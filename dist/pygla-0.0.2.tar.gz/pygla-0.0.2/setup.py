from setuptools import setup

setup(name='pygla',
      version='0.0.2',
      description='Automate group learning assessment',
      author='rpb',
      author_email = 'balandongiv@gmail.com',
      packages=['gla'],
      long_description='NA',
      install_requires=[
            'pandas',
      ]
      )
