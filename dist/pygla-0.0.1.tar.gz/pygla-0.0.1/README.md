# pygla
Python Group Learning Assessment (PyGLA) is a library package name that reflects the concept of group-based learning and assessing individual contributions within the group. More detail available on the paper "The Evolution of a Peer Assessment Method for use in Groupbased Teaching of HCI"
